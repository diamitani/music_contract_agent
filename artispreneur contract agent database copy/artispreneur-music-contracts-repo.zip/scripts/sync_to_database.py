#!/usr/bin/env python3
"""
Sync the contract library to Supabase or any PostgreSQL database.

This script reads the CSV export and loads it into a PostgreSQL-compatible
database (Supabase, AWS RDS, Google Cloud SQL, or local development).

Two modes:
  1. FLAT: Just load the CSV export as-is into a single flat table.
     Fast, simple, good for getting started quickly.
  2. NORMALIZED: Create the normalized schema (contracts, contract_rights,
     contract_parties, contract_risk_flags, contract_details) and migrate
     the CSV data into it. More complex but scalable and queryable.

Requires: python-dotenv, psycopg2 (or psycopg[binary] for easier install)
Install: pip install psycopg python-dotenv

Environment variables (use a .env file or set directly):
  DATABASE_URL  — PostgreSQL connection string (required)
                  Supabase: postgresql://user:password@project.supabase.co:5432/postgres
                  AWS RDS: postgresql://user:password@your-endpoint.rds.amazonaws.com:5432/dbname
  SYNC_MODE     — 'flat' or 'normalized' (default: 'flat')

Usage:
  export DATABASE_URL="postgresql://..."
  python3 scripts/sync_to_database.py [--mode flat|normalized] [--csv path/to/export.csv]
"""
import argparse
import csv
import os
import sys

try:
    import psycopg
except ImportError:
    print("psycopg is required. Install with: pip install psycopg python-dotenv")
    sys.exit(1)

try:
    from dotenv import load_dotenv
except ImportError:
    load_dotenv = lambda: None

load_dotenv()

HERE = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.dirname(HERE)
DEFAULT_CSV = os.path.join(REPO_ROOT, "outputs", "contracts_export.csv")

SCHEMA_FLAT = """
CREATE TABLE IF NOT EXISTS contracts (
  id VARCHAR(255) PRIMARY KEY,
  title VARCHAR(255),
  status VARCHAR(50),
  category VARCHAR(100),
  parties TEXT,
  rights_affected TEXT,
  money_fields TEXT,
  rights_grant_notes TEXT,
  control_fields TEXT,
  intake_questions TEXT,
  template_file VARCHAR(255),
  questionnaire_file VARCHAR(255),
  github_template_link TEXT,
  github_questionnaire_link TEXT,
  github_yaml_link TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""

SCHEMA_NORMALIZED = """
CREATE TABLE IF NOT EXISTS contracts (
  id VARCHAR(255) PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  status VARCHAR(50),
  category VARCHAR(100),
  template_file VARCHAR(255),
  questionnaire_file VARCHAR(255),
  github_yaml_link TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS contract_parties (
  id SERIAL PRIMARY KEY,
  contract_id VARCHAR(255) REFERENCES contracts(id) ON DELETE CASCADE,
  party_name VARCHAR(255),
  position INT
);

CREATE TABLE IF NOT EXISTS contract_rights (
  id SERIAL PRIMARY KEY,
  contract_id VARCHAR(255) REFERENCES contracts(id) ON DELETE CASCADE,
  right_type VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS contract_details (
  contract_id VARCHAR(255) PRIMARY KEY REFERENCES contracts(id) ON DELETE CASCADE,
  money_fields TEXT,
  rights_grant_notes TEXT,
  control_fields TEXT,
  intake_questions TEXT
);

CREATE TABLE IF NOT EXISTS contract_risk_flags (
  id SERIAL PRIMARY KEY,
  contract_id VARCHAR(255) REFERENCES contracts(id) ON DELETE CASCADE,
  severity VARCHAR(50),
  text TEXT,
  position INT
);
"""


def load_csv(csv_path):
    """Load contracts from CSV file."""
    records = []
    with open(csv_path, encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            records.append(row)
    return records


def sync_flat(conn, records):
    """Load CSV records into a single flat contracts table."""
    with conn.cursor() as cur:
        cur.execute("TRUNCATE TABLE contracts CASCADE;")
        conn.commit()

        # Insert records
        for record in records:
            # Build column names and values dynamically
            cols = list(record.keys())
            vals = [record[c] for c in cols]
            placeholders = ",".join(["%s"] * len(cols))
            col_str = ",".join(cols)
            sql = f"INSERT INTO contracts ({col_str}) VALUES ({placeholders})"
            cur.execute(sql, vals)

        conn.commit()
        print(f"Loaded {len(records)} contracts into flat schema.")


def sync_normalized(conn, records):
    """Load CSV records into the normalized schema."""
    with conn.cursor() as cur:
        # Clear existing data
        cur.execute("TRUNCATE TABLE contract_risk_flags CASCADE;")
        cur.execute("TRUNCATE TABLE contract_details CASCADE;")
        cur.execute("TRUNCATE TABLE contract_rights CASCADE;")
        cur.execute("TRUNCATE TABLE contract_parties CASCADE;")
        cur.execute("TRUNCATE TABLE contracts CASCADE;")
        conn.commit()

        # Insert into contracts table
        for record in records:
            cur.execute(
                """INSERT INTO contracts (id, title, status, category, template_file, questionnaire_file, github_yaml_link)
                   VALUES (%s, %s, %s, %s, %s, %s, %s)""",
                (
                    record["id"],
                    record["title"],
                    record["status"],
                    record["category"],
                    record["template_file"],
                    record["questionnaire_file"],
                    record["github_yaml_link"],
                ),
            )

        conn.commit()

        # Insert parties
        for record in records:
            parties = [p.strip() for p in record["parties"].split(" | ") if p.strip()]
            for pos, party in enumerate(parties, start=1):
                cur.execute(
                    """INSERT INTO contract_parties (contract_id, party_name, position)
                       VALUES (%s, %s, %s)""",
                    (record["id"], party, pos),
                )

        conn.commit()

        # Insert rights_affected
        for record in records:
            rights = [r.strip() for r in record["rights_affected"].split(" | ") if r.strip()]
            for right in rights:
                cur.execute(
                    """INSERT INTO contract_rights (contract_id, right_type)
                       VALUES (%s, %s)""",
                    (record["id"], right),
                )

        conn.commit()

        # Insert contract_details
        for record in records:
            cur.execute(
                """INSERT INTO contract_details (contract_id, money_fields, rights_grant_notes, control_fields, intake_questions)
                   VALUES (%s, %s, %s, %s, %s)""",
                (
                    record["id"],
                    record["money_fields"],
                    record["rights_grant_notes"],
                    record["control_fields"],
                    record["intake_questions"],
                ),
            )

        conn.commit()

        # Insert risk flags
        for record in records:
            pos = 1
            for i in range(1, 20):  # Check up to 20 risk flags
                severity_key = f"risk_{i}_severity"
                text_key = f"risk_{i}_text"
                if severity_key in record and record.get(text_key):
                    cur.execute(
                        """INSERT INTO contract_risk_flags (contract_id, severity, text, position)
                           VALUES (%s, %s, %s, %s)""",
                        (record["id"], record[severity_key], record[text_key], pos),
                    )
                    pos += 1

        conn.commit()
        print(f"Loaded {len(records)} contracts into normalized schema.")


def main():
    parser = argparse.ArgumentParser(description="Sync contract library to PostgreSQL database")
    parser.add_argument("--mode", choices=["flat", "normalized"], default="flat")
    parser.add_argument("--csv", default=DEFAULT_CSV, help="Path to contracts_export.csv")
    args = parser.parse_args()

    db_url = os.getenv("DATABASE_URL")
    if not db_url:
        print("Error: DATABASE_URL environment variable is not set.")
        print("Set it in a .env file or: export DATABASE_URL='postgresql://...'")
        sys.exit(1)

    csv_path = args.csv
    if not os.path.isfile(csv_path):
        print(f"Error: CSV file not found: {csv_path}")
        sys.exit(1)

    # Connect to database
    try:
        conn = psycopg.connect(db_url)
    except Exception as e:
        print(f"Error connecting to database: {e}")
        sys.exit(1)

    # Create schema
    try:
        with conn.cursor() as cur:
            if args.mode == "flat":
                cur.execute(SCHEMA_FLAT)
            else:
                cur.execute(SCHEMA_NORMALIZED)
        conn.commit()
        print(f"Schema created ({args.mode} mode)")
    except Exception as e:
        print(f"Error creating schema: {e}")
        conn.close()
        sys.exit(1)

    # Load CSV
    try:
        records = load_csv(csv_path)
        print(f"Loaded {len(records)} records from {csv_path}")
    except Exception as e:
        print(f"Error reading CSV: {e}")
        conn.close()
        sys.exit(1)

    # Sync to database
    try:
        if args.mode == "flat":
            sync_flat(conn, records)
        else:
            sync_normalized(conn, records)
        print("✓ Sync complete!")
    except Exception as e:
        print(f"Error syncing: {e}")
        conn.close()
        sys.exit(1)

    conn.close()


if __name__ == "__main__":
    main()
