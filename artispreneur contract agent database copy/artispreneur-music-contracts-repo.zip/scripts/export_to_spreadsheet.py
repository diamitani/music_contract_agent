#!/usr/bin/env python3
"""
Export the Artispreneur Music Contract Library to XLSX and CSV formats
suitable for database upload (Supabase, AWS RDS, Google Sheets, etc.).

Generates two files:
  1. contracts_export.xlsx — Excel workbook with flattened contract metadata
  2. contracts_export.csv — CSV version of the same data

Input: references/contracts/*.yaml files.
Output: /mnt/user-data/outputs/ (or REPO_ROOT/outputs/)

Each row represents one contract record, with complex fields flattened:
  - arrays (rights_affected, money_fields, etc.) become pipe-separated strings
  - risk_flags array is unpacked into separate columns (risk_1_severity,
    risk_1_text, risk_2_severity, risk_2_text, ..., risk_n_severity,
    risk_n_text)
  - intake_questions array becomes pipe-separated

This structure is normalized-ish (one contract = one row, no array duplicates)
and designed to fit into a single table or be split into related tables
(e.g. contracts + contract_risks, contracts + contract_questions).

See DATABASE_SCHEMA.md for how to normalize this further for production RDS/
Supabase use.

Usage: python3 scripts/export_to_spreadsheet.py
"""
import csv
import glob
import os
import sys

import yaml
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

HERE = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.dirname(HERE)
SKILL_DIR = os.path.join(REPO_ROOT, "skills", "music-contract-agent")
REFS = os.path.join(SKILL_DIR, "references")
YAML_DIR = os.path.join(REFS, "contracts")
OUTPUT_DIR = os.path.join(REPO_ROOT, "outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)


def load_records():
    records = []
    for path in sorted(glob.glob(os.path.join(YAML_DIR, "*.yaml"))):
        with open(path, encoding="utf-8") as f:
            records.append(yaml.safe_load(f))
    return records


def flatten_record(record):
    """Flatten a YAML record into a single dict suitable for a spreadsheet row."""
    risk_max = max(len(record.get("risk_flags", [])), 1)
    flat = {
        # Basic fields
        "id": record.get("id"),
        "title": record.get("title"),
        "status": record.get("status"),
        "category": record.get("category"),
        # Simple array fields as pipe-separated strings
        "parties": " | ".join(record.get("parties", [])),
        "rights_affected": " | ".join(record.get("rights_affected", [])),
        "money_fields": " | ".join(record.get("money_fields", [])),
        "rights_grant_notes": " | ".join(record.get("rights_grant_notes", [])),
        "control_fields": " | ".join(record.get("control_fields", [])),
        "intake_questions": " | ".join(record.get("intake_questions", [])),
        # File references
        "template_file": record.get("template_file"),
        "questionnaire_file": record.get("questionnaire_file"),
        # GitHub repo links (construct from id)
        "github_template_link": f"https://github.com/[YOUR-REPO]/blob/main/skills/music-contract-agent/references/templates/{record.get('template_file')}",
        "github_questionnaire_link": f"https://github.com/[YOUR-REPO]/blob/main/skills/music-contract-agent/references/questionnaires/{record.get('questionnaire_file')}",
        "github_yaml_link": f"https://github.com/[YOUR-REPO]/blob/main/skills/music-contract-agent/references/contracts/{record.get('id')}.yaml",
    }

    # Unpack risk_flags into separate columns (risk_1_severity, risk_1_text, ...)
    for i, risk in enumerate(record.get("risk_flags", []), start=1):
        flat[f"risk_{i}_severity"] = risk.get("severity")
        flat[f"risk_{i}_text"] = risk.get("text")

    return flat


def export_xlsx(records, output_path):
    """Export records to XLSX with styling."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Contracts"

    # Get all possible column names from the flattened records
    all_keys = set()
    for rec in records:
        flat = flatten_record(rec)
        all_keys.update(flat.keys())

    # Define column order: basic fields first, then grouped, then risks
    basic_cols = [
        "id",
        "title",
        "status",
        "category",
        "parties",
        "rights_affected",
    ]
    detail_cols = [
        "money_fields",
        "rights_grant_notes",
        "control_fields",
        "intake_questions",
    ]
    file_cols = [
        "template_file",
        "questionnaire_file",
        "github_template_link",
        "github_questionnaire_link",
        "github_yaml_link",
    ]
    risk_cols = sorted([k for k in all_keys if k.startswith("risk_")])

    column_order = basic_cols + detail_cols + file_cols + risk_cols

    # Write header row
    for col_idx, col_name in enumerate(column_order, start=1):
        cell = ws.cell(row=1, column=col_idx)
        cell.value = col_name
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    # Write data rows
    for row_idx, record in enumerate(records, start=2):
        flat = flatten_record(record)
        for col_idx, col_name in enumerate(column_order, start=1):
            cell = ws.cell(row=row_idx, column=col_idx)
            cell.value = flat.get(col_name, "")
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            # Light alternating row color
            if row_idx % 2 == 0:
                cell.fill = PatternFill(start_color="F0F0F0", end_color="F0F0F0", fill_type="solid")

    # Set column widths based on content type
    for col_idx, col_name in enumerate(column_order, start=1):
        col_letter = get_column_letter(col_idx)
        if col_name == "id":
            ws.column_dimensions[col_letter].width = 30
        elif col_name == "title":
            ws.column_dimensions[col_letter].width = 40
        elif col_name == "status":
            ws.column_dimensions[col_letter].width = 12
        elif col_name == "category":
            ws.column_dimensions[col_letter].width = 25
        elif col_name.startswith("risk_"):
            ws.column_dimensions[col_letter].width = 20
        elif "link" in col_name:
            ws.column_dimensions[col_letter].width = 60
        else:
            ws.column_dimensions[col_letter].width = 35

    # Freeze the header row
    ws.freeze_panes = "A2"

    wb.save(output_path)


def export_csv(records, output_path):
    """Export records to CSV."""
    # Collect all possible keys
    all_keys = set()
    for rec in records:
        flat = flatten_record(rec)
        all_keys.update(flat.keys())

    # Column order (same as XLSX)
    basic_cols = [
        "id",
        "title",
        "status",
        "category",
        "parties",
        "rights_affected",
    ]
    detail_cols = [
        "money_fields",
        "rights_grant_notes",
        "control_fields",
        "intake_questions",
    ]
    file_cols = [
        "template_file",
        "questionnaire_file",
        "github_template_link",
        "github_questionnaire_link",
        "github_yaml_link",
    ]
    risk_cols = sorted([k for k in all_keys if k.startswith("risk_")])
    column_order = basic_cols + detail_cols + file_cols + risk_cols

    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=column_order, restval="")
        writer.writeheader()
        for record in records:
            flat = flatten_record(record)
            writer.writerow(flat)


def main():
    records = load_records()
    if not records:
        print("No YAML records found.")
        sys.exit(1)

    xlsx_path = os.path.join(OUTPUT_DIR, "contracts_export.xlsx")
    csv_path = os.path.join(OUTPUT_DIR, "contracts_export.csv")

    export_xlsx(records, xlsx_path)
    export_csv(records, csv_path)

    print(f"Exported {len(records)} contracts:")
    print(f"  XLSX: {xlsx_path}")
    print(f"  CSV:  {csv_path}")


if __name__ == "__main__":
    main()
