POPULAR SONGWRITER'S CONTRACT

AGREEMENT entered into this day of 20 , by and between herein designated
as the PUBLISHER, and author and/or composer, hereinafter jointly
designated as the COMPOSER.

> WITNESSETH:
>
> 1. The COMPOSER hereby sells, assigns, transfers and delivers to the
> PUBLISHER, its successors and assigns, the original musical
> composition written and composed by at present entitled which title
> may be changed by the PUBLISHER; including the title, words and music
> thereof, and all rights therein, and all copyrights and the rights to
> secure copyrights and any extensions and renewals of copyrights in the
> same and in any arrangements and adaptations thereof, throughout the
> world; and any and all other rights that the COMPOSER now has or to
> which he may be entitled or that he hereafter could or might secure
> with respect to this composition, if these presents had not been made,
> throughout the world; and to have and to hold the same absolutely unto
> the PUBLISHER its successors and assigns.
>
> 2. The COMPOSER hereby convenants, represents and warrants that the
> composition hereby sold is an original work and that neither said work
> nor any part thereof infringes upon the title of the literary or
> musical property or the copyright in any other work, and that he is
> the sole writer and composer and the sole owner thereof and of all the
> rights therein, and has not sold, assigned, set over, transferred,
> hypothecated or mortgaged any right, title or interest in or to the
> said composition or any part thereof, or any of the rights herein
> conveyed, and that he has not made or entered into any contract or
> contracts with any other person, firm or corporation whomsoever,
> affecting said composition or any right, title or interest therein, or
> in the copyright thereof, and that no person, firm or corporation
> other than the COMPOSER has or has had claims, or has claimed any
> right, title or interest in or to said work or any part thereof or any
> use thereof or any copyright therein, and that said work has never
> been published, and that the Composer has full right, power and
> authority to make this present instrument of sale and transfer.
>
> 3. In consideration of this agreement, the PUBLISHER agrees to pay
> the COMPOSER as follows:
>
> (a) An advance of is hand paid, receipt of which is hereby
> acknowledged; or any other sum heretofore or hereafter advanced to the
> COMPOSER, which total sums shall be deductible from any payments
> hereafter becoming due to the COMPOSER under this agreement.
>
> (b) A royalty of cents per copy on all regular piano copies sold and
> paid for in the United States of America.
>
> (c) A royalty of cents per copy on any form of orchestration thereof
> sold and paid for in the United States of America.
>
> (d) A royalty of for each use of the lyrics and music together, in
> any song book, song sheet, folio or similar publication containing at
> least five musical compositions.
>
> (e) For purposes of royalty statements, if a composition is printed
> and published in the United States, as to copies and rights sold in
> Dominion of Canada, revenue therefrom shall be considered as of
> domestic origin. If, however, the composition is printed by a party
> other than the PUBLISHER in the Dominion of Canada, revenue therefrom
> shall be considered as originating in a foreign country.
>
> (f) An amount equal to % of all net receipts of the PUBLISHER in
> respect of any license issued authorizing the manufacture of the parts
> of instruments serving to mechanically reproduce the said composition,
> or to use the said composition in synchronization with sound motion
> pictures, or to reproduce it upon so called "electrical
> transcriptions" for broadcasting purposes; and of any and all net
> receipts of the PUBLISHER from any other source or right now known or
> which may hereafter come into existence.
>
> (g) A royalty of % of all net sums received by the PUBLISHER on
> regular piano copies and/or orchestrations thereof, and for the use of
> said composition in any folio or composite work, sold and paid for in
> any foreign country.
>
> (h) In the event that the said Composition shall not now have
> lyrics, and lyrics are added to the said composition, the above
> royalties shall be divided equally between the COMPOSER and the other
> writers and composers.
>
> 4. It is specifically understood and agreed that the intention of
> this agreement is not, and the COMPOSER shall not be entitled to
> receive any part of the monies received by the PUBLISHER from the
> American Society of Composers, Authors and Publishers, or any other
> performance right society from which the PUBLISHER shall receive
> payments for the use of said musical composition in all countries of
> the world.
>
> 5. It is agreed that no royalties are to be paid for professional
> copies, copies disposed of as new issues, copies distributed for
> advertising purposes, or lyrics or music separately printed in any
> folio, book, newspaper, song sheet, lyric folio or magazine, or any
> other periodical, except as above set forth. It is also distinctly
> understood that no royalties are payable on consigned copies unless
> paid for, and not until such time as an accounting therefor can
> properly be made.
>
> 6. The PUBLISHER agrees that it will render to the COMPOSER
> semi-annually on or about the 15th day of February and August of each
> year, a statement showing all sales showing all sales and royalties
> earned by the said COMPOSER to the preceding December 31st and June
> 30th and will pay to him at the same time all royalties then due and
> owing.
>
> 7. The COMPOSER hereby expressly grants and conveys to the PUBLISHER
> the copyright of the aforesaid composition, with renewals, and with
> the right to copyright and renew the same, and the right to secure all
> copyrights and renewals of copyright and any and all rights therein
> that the COMPOSER may at any time be entitled to, and agrees to sign
> any and all other papers which may be required to effectuate this
> agreement. And the COMPOSER does hereby Irrevocably authorize and
> appoint the PUBLISHER, its successors or assigns, his attorneys and
> representatives in their name or in his name to take and do such
> actions, deeds and things and make, sign, execute, acknowledge and
> deliver all such documents as may from time to time be necessary to
> secure the renewals and extensions of the copyright in the aforesaid
> composition, and to assign to the PUBLISHER, its successors and
> assigns, said renewal copyrights and all rights therein for the term
> of such renewals and extensions and the COMPOSER agrees upon the
> expiration of the first term of any copyright in the aforesaid
> composition in this or in any contract, to do, make, execute,
> acknowledge and deliver, or to procure the due execution,
> acknowledgement and delivery to the PUBLISHER, of all papers necessary
> in order to secure to it the renewals and extension of all copyrights
> in said compositions and all rights therein for the terms of such
> renewals and extensions.
>
> 8. The PUBLISHER agrees to publish the said musical composition in
> saleable form within one year after the receipt of lead sheet of the
> said composition. Should it fail to do so, the COMPOSER shall have the
> right, in writing, by registered mail, to demand the return of such
> unpublished composition, whereupon the PUBLISHER must within sixty
> days after receipt of such notice either publish the said composition,
> in which event this agreement shall remain in full force and effect,
> or upon failure so to publish, all rights of any and every nature
> granted to the PUBLISHER herein in connection with the said
> unpublished composition shall revert to and become the property of the
> COMPOSER and shall be reassigned to him.

In connection with the foregoing it is distinctly understood and agreed
that if the PUBLISHER shall secure a commercial phonograph recording, or
an electrical transcription, or, a synchronization in a motion picture,
of the said composition; such recording, transcription or
synchronization shall, for the purposes of this agreement, be deemed
publication by the PUBLISHER.

> 9. The COMPOSER agrees that he will not transfer nor assign this
> agreement nor any interest therein nor any sums that may be or become
> due hereunder without the written consent of the PUBLISHER first
> hereon endorsed, and no purported assignment or transfer in violation
> of this restriction shall be valid to pass any interest to the
> assignee or transferee.
>
> 10. The COMPOSER hereby authorized the PUBLISHER at its absolute
> discretion and at the COMPOSER'S sole expense to employ attorneys and
> to institute or defend any action or proceeding and to take any other
> proper steps to protect the right, title and interest of the PUBLISHER
> in and to the above entitled composition and every portion thereof
> acquired from the COMPOSER pursuant to the terms hereof and in that
> connection to settle, compromise or in any other manner dispose of any
> matter, claim, action, or proceeding and to satisfy any judgement that
> may be rendered and all of the expense so incurred and other sums so
> paid by the PUBLISHER the COMPOSER hereby agrees to pay to the
> PUBLISHER on demand, further authorizing the PUBLISHER, whenever in
> its opinion its right, title or interest to any of the writer's
> composition are questioned or there is a breach of any of the
> covenants, warranties or representations contained in this contract or
> in any other similar contract heretofore or hereafter entered into
> between the PUBLISHER and the COMPOSER, to withhold any and.all
> royalties that may be or become due to the COMPOSER pursuant to all
> such contracts until such question shall have been settled or such
> breach repaired, and to apply such royalties to the repayment of all
> sums due to the PUBLISHER hereunder.
>
> 11. The term COMPOSER shall be understood to include all the authors
> and composers of the musical composition above referred to. If there
> be more than one, the covenants herein contained shall be deemed to be
> both joint and several on the part of the writers and composers and
> the royalties hereinabove specified to be paid to the COMPOSER, shall,
> unless a different division of royalty be specified, be due to all the
> writers and composers collectively, to he paid by the PUBLISHER, in
> equal shares to each. This agreement may be executed by writers and
> composers in several counterparts.
>
> 12. All questions and differences whatsoever which may at any time
> hereafter arise between the parties hereto touching these presents or
> the subject matter thereof, or arising out of or in relation thereto,
> and whether as to construction or otherwise, may be referred to
> arbitration under the provisions and the supervision of the American
> Arbitration Association.
>
> 13. This agreement contains the entire understanding between the
> parties, and all of its terms, conditions and covenants shall be
> binding upon and shall inure to the benefit of the respective parties
> and their heirs, successors and assigns. No modification or waiver
> hereunder shall be valid unless the same is in writing and is signed
> by the parties hereto.

IN WITNESS WHEREOF, the parties hereto have executed this agreement the
day and year first above written.

By

witness

Composer

WITNESS Address

Composer

WITNESS Address

Composer

WITNESS Address

Publisher

WITNESS Address
