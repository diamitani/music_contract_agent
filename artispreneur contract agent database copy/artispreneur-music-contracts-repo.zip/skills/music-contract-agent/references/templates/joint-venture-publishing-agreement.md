JOINT VENTURE CONTRACT

(Publisher) (Record Company) (Record Distributor)

The undersigned, desiring to enter into a joint venture, agree as
follows:

l. The name of the joint venture shall be:

2. The character of the business shall be:

> (a) the publishing of music;
>
> (b) the production of phonograph record masters and phonograph
> records;
>
> (c) the promotion and distribution of phonograph records; and
>
> (d) all other business necessary and related thereto.

3. The location of the principal place of business shall be:

4. The name and place of residence of each of the undersigned is:

5. Each of the undersigned shall contribute cash and property, and
shall receive percentages of the net profit of the joint venture as
follows:

[Name]{.underline} [Cash]{.underline} [Property]{.underline} [% of Net
Profit]{.underline}

Losses shall be shared in the same ratios as net profit.

6. Each of the undersigned may make additional contributions to, or
withdrawals from, the capital of the joint venture as may from time to
time be agreed upon by all the partners.

7. The joint venture shall continue as long as the undersigned desire.

8. In the event of retirement, expulsion, bankruptcy, death or insanity
of a member of the joint venture, the remaining members shall have the
right to continue the business of the joint venture under the same name
by themselves, or in conjunction with any other person or persons whom
they may select.

9. The members of the joint venture have the right to admit additional
members by unanimous decision only.

IN WITNESS WHEREOF, the undersigned members of the joint venture have
hereunto set their hands this day:

________________________________________
______________________________________

________________________________________
______________________________________

________________________________________
______________________________________
