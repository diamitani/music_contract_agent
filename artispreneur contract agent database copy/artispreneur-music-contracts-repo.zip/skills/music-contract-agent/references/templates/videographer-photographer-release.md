# RECORDED VIDEO PERFORMANCE RELEASE

I, _________, hereby grant _________________
and its agents the right to video/audio tape my
likeness/voice/performance and/or the likeness/voice/performance of
________________ (name of group), in connection with the
production and distribution of the video/audio tape presentation named
below, and that said video/audio tape may be broadcast or otherwise
transmitted by ______________ its successors or assigns. I
agree that you may copyright said video/audio tape.

I further agree that my name(s) likeness/voice(s) and biographical
material may be used in connection with publicity about the production
named below.

I understand that the recorded material will not be used for commercial
gain, but excerpts may be used in compilations or other promotional
activities. I release _____________ and their agents,
successors and assigns from further claims or demands arising from the
uses of materials you may record in which I/we appear or can be heard.

Production:
_______________________________

Date: _________________________ Signature
_________________________________

Address:
__________________________________

__________________________________

__________________________________

Phone
___________________________________
