ARTIST RECORDING CONTRACT

1. AGREEMENT made this __________________ day of
___________________, 20______,

between
___________________________________________________
(herein called "the Company")

and (herein called "the Artist")

for the tendering of personal services in connection with the production
of Commercial Sound Records.

2. This agreement shall remain in effect for a period of from the date
hereof, and during that period you will, at mutually convenient times,
come to and perform at the Company's recording studios for the purpose
of recording selections or more than this number if the Company so
desires.

In consideration of this Agreement and without further payment than as
herein provided for yourself, you grant to the Company, its associates,
subsidiaries and nominees (1) the right to manufacture, advertise, sell,
lease, license or otherwise use or dispose of in any or all fields of
use, throughout the world, or to refrain therefrom, throughout the world
or any part thereof, records embodying the performances to be recorded
hereunder, upon such terms and conditions as the Company may approve;
(2) the right to use your name and photograph if desired, in connection
with the exploitation of said records; and (3) all rights in and to the
matrices and records, and the use and control thereof, upon which are
reproduced the performances to be recorded hereunder.

3. The Company will pay you for the rights granted herein and the
services to be rendered hereunder by you a royalty of
______________________cents for each double-faced
record manufactured and sold throughout the world by the Company or its
associates or subsidiaries, on both faces of which are embodied any of
the selections recorded hereunder. In case of records manufactured and
sold by the Company on only one face of which is embodied a selection
recorded hereunder, the amount of royalty shall be one-half of the
amount set forth above, excepting in cases where the recording shall be
of full length on one side (in such case as a Compact Disk).

4. Payment of accrued royalties shall be made semi-annually on the
first day of ____________________ for the period
ending , and on the first day of for the period ending of each year. The
Company, however, shall have the right to deduct from the amount of any
statements, or accounts of royalties due, the amount of royalties
previously paid to you or records subsequently returned, either as
defective or on exchange proposition.

5. You agree that during the period of this Agreement you will not
perform for any other person, firm or corporation, for the purpose of
producing commercial sound records, that after the expiration of this
Agreement you will not record for anyone else any of the musical
selections recorded hereunder, and that in the event of a breach of this
covenant, the Company shall be entitled to an injunction to enforce
same, in addition to any other remedies available to it.

6. The Artist hereby warrants that he has no oral or written
obligations contracts, or agreements of whatever nature entered into
prior to the signing of this agreement which are now in force and
binding and which would in any way interfere with carrying out this
agreement to its full intent and purpose.

7. If any instrumental musicians whose services are engaged hereunder
are members of the American Federation of Musicians, the following
provision shall be deemed to be a part of this agreement:

> "As the musicians engaged under the stipulations of this contract are
> members of the American Federation of Musicians, nothing in this
> contract shall ever be construed as to interfere with any obligation
> which they owe to the American Federation of Musicians as members
> thereof."

8. It is mutually understood and agreed that in the event the license
issued to the Company by the American Federation of Musicians, and
pursuant to which the Company engages the services of Federation members
as instrumental musicians, should be revoked or terminated, with or
without cause, and in the event you or any of the members of the Musical
Organization are members of the Federation, the Company may, at its
option, terminate and cancel this agreement without liability to you.

9. The Company shall have the privilege and option to extend this
Agreement from the date of its expiration for a period equal to the
terms of this Agreement by giving to you notice in writing of its
exercise of such option and its election to continue. Such notice shall
be given to you personally or be mailed to your last known address not
less than ten days prior to the expiration of this Agreement. Upon the
giving of such notice this Agreement shall be continued and extended for
such further period upon the same terms as those above set forth.

ACCEPTED AND AGREED TO:

BY:
